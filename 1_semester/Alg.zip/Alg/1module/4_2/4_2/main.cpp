//
//  main.cpp
//  4_2
//
//  Created by Дмитрий  Загребаев on 13.03.16.
//  Copyright © 2016 Дмитрий  Загребаев. All rights reserved.
//

#include <iostream>
#include <string.h>

#define YES ("YES")
#define NO ("NO")
#define INIT_SIZE (65536)
#define SCALE (2)

class Deque {
    
private:
    int *arrNumbers;
    size_t countOfelems;
    size_t arrSize;
    size_t firstIndex;
    size_t lastIndex;
    size_t startIndex;
    
public:
    Deque();
    Deque(size_t scale);
    ~Deque();
    
public:
    Deque *pushBack(int num);
    int popBack();
    
    Deque *pushFront(int num);
    int popFront();
    
public:
    bool isEmpty();
};

bool getStatus(Deque *deque);

int main(int argc, const char * argv[]) {
    
    Deque *deque = new Deque();
    
    if (getStatus(deque)) {
        std::cout << YES;
    } else std:: cout << NO;
    
    delete deque;
    
    return 0;
}

/*------------------------------------------------------------------------------------------------*/

Deque::Deque() {
    this->arrNumbers = (int*)malloc(sizeof(int) * INIT_SIZE);
    memset(this->arrNumbers, 0, sizeof(int) * INIT_SIZE);
    this->arrSize        = INIT_SIZE;
    this->countOfelems   = 0;
    this->startIndex     = INIT_SIZE / 2;
    this->firstIndex = this->startIndex;
    this->lastIndex    = this->startIndex;
}


/*------------------------------------------------------------------------------------------------*/

Deque::Deque(size_t scale) {
    
}

/*------------------------------------------------------------------------------------------------*/

Deque::~Deque() {
    free(this->arrNumbers);
}

/*------------------------------------------------------------------------------------------------*/


/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/

bool Deque::isEmpty() {
    return countOfelems == 0 ? true : false;
}

/*------------------------------------------------------------------------------------------------*/

Deque* Deque::pushFront(int num) {
    
//    std::cout << "pushFront\n";
    
    if (countOfelems == 0) {
        this->lastIndex++;
    }
    
    this->arrNumbers[this->firstIndex] = num;
    
    this->firstIndex--;
    
    this->countOfelems++;
    
//    std::cout << "pushFront " << firstIndex << " " << lastIndex << " " <<countOfelems << "\n";
    
    return this;
}

/*------------------------------------------------------------------------------------------------*/

int Deque::popFront() {
    
//    std::cout << "popFront\n";
    
    if (this->isEmpty()) {
        return -1;
    }
    
    int result = 0;
    this->firstIndex++;
    result = this->arrNumbers[firstIndex];
    this->countOfelems--;
    
    if (countOfelems == 0) {
        this->firstIndex = this->lastIndex = this->arrSize / 2;
    }

    
//    std::cout << "popFront " << firstIndex << " " << lastIndex << " " <<countOfelems << "\n";

    
    return result;
}

/*------------------------------------------------------------------------------------------------*/

Deque* Deque::pushBack(int num) {
    
//    std::cout << "pushBack\n";
    
    if (this->countOfelems == 0) {
        this->firstIndex--;
    }
    
    this->arrNumbers[lastIndex] = num;
    
    this->lastIndex++;
    this->countOfelems++;
    
    
//    std::cout << "pushBack " << firstIndex << " " << lastIndex << " " <<countOfelems << "\n";

    
    return this;
}

int Deque::popBack() {
    
//    std::cout << "popBack\n";
    
    if (this->countOfelems == 0) {
        return -1;
    }
    
    int result = 0;
    this->lastIndex--;
    result = this->arrNumbers[this->lastIndex];
    this->countOfelems--;
    
    if (countOfelems == 0) {
        this->firstIndex = this->lastIndex = this->arrSize / 2;
    }
    
//    std::cout << "popBack " << firstIndex << " " << lastIndex << " " <<countOfelems << "\n";

    
    
    return result;
}

/*------------------------------------------------------------------------------------------------*/



/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/

bool getStatus( Deque *deque) {
    size_t countOfComands = 0;
    int exp = 0;
    int comand = 0;
    
    std::cin >> countOfComands;
    
    for (size_t i = 0; i < countOfComands; i++) {
        std::cin >> comand >> exp;
        switch (comand) {
            case 1:
                deque->Deque::pushFront(exp);
                break;
                
            case 2:
                if(deque->Deque::popFront() != exp)
                    return false;
                break;
                
            case 3:
                deque->pushBack(exp);
                break;
                
            case 4:
                if (deque->popBack() != exp)
                    return false;
                break;
                
            default:
                break;
        }
    }
    
    return true;
}

/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------*/

























































